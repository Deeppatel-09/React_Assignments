const input = document.querySelector("#todo-input");
const submitButton = document.querySelector("#submit-button");
const todoList = document.querySelector("#todo-list");

submitButton.addEventListener("click", function(event) {
  event.preventDefault();
  const todo = input.value;
  input.value = "";

  const todoItem = document.createElement("li");
  todoItem.textContent = todo;

  todoList.appendChild(todoItem);

  todoItem.addEventListener("click", function() {
    todoItem.style.textDecoration = "line-through";
  });
});
